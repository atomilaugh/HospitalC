from django.apps import AppConfig

class TpacienteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tPaciente'

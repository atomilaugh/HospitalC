from django.db import models

class Paciente(models.Model):
    dni = models.CharField(max_length=20)
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    fechaNacimiento = models.DateField()

    def __str__(self):
        return f"{self.nombre} {self.apellido}"

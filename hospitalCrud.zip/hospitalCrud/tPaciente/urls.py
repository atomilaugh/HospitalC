from django.urls import path
from .views import lista_pacientes, nuevo_paciente, editar_paciente, borrar_paciente

urlpatterns = [
    path('', lista_pacientes, name='lista_pacientes'),
    path('nuevo/', nuevo_paciente, name='nuevo_paciente'),
    path('editar/<int:pk>/', editar_paciente, name='editar_paciente'),
    path('borrar/<int:pk>/', borrar_paciente, name='borrar_paciente'),
]

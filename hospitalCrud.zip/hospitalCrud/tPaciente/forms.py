from django import forms
from .models import Paciente

class PacienteForm(forms.ModelForm):
    class Meta:
        model = Paciente
        fields = ['dni', 'nombre', 'apellido', 'fechaNacimiento']
        widgets = {
            'fechaNacimiento': forms.DateInput(attrs={'type': 'date'})
        }
